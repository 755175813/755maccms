<?php
return array (
  '﻿www.mj8.tw' => 
  array (
    'site_url' => '﻿www.mj8.tw',
    'site_name' => '高清美剧吧',
    'site_keywords' => '高清美剧吧_美剧吧_美剧迅雷下载吧',
    'site_description' => '高清美剧吧，最新高清超清影片在线下载',
    'template_dir' => 'stui_tpl',
    'mob_template_dir' => 'paody',
    'html_dir' => '755175813',
    'ads_dir' => '',
  ),
  'www.hanjuba.tw' => 
  array (
    'site_url' => 'www.hanjuba.tw',
    'site_name' => '高清韩剧吧',
    'site_keywords' => '高清韩剧吧_高清韩剧tv_韩剧高清网',
    'site_description' => '高清韩剧吧，最新高清超清韩剧电影电视剧片在线下载',
    'template_dir' => 'ak',
    'mob_template_dir' => 'stui_tpl',
    'html_dir' => '755175813',
    'ads_dir' => '',
  ),
  'www.91dy.tw' => 
  array (
    'site_url' => 'www.91dy.tw',
    'site_name' => '91电影网',
    'site_keywords' => '91电影网_高清电影吧_高清91电影_电影高清网',
    'site_description' => '高清91电影吧，最新高清超清电影电视剧片在线下载',
    'template_dir' => 'ak',
    'mob_template_dir' => 'stui_tpl',
    'html_dir' => '755175813',
    'ads_dir' => '',
  ),
  'www.mp4m.com' => 
  array (
    'site_url' => 'www.mp4m.com',
    'site_name' => '视频妈影院',
    'site_keywords' => '视频妈影院电影网_高清电影吧_高清电影_电影高清网',
    'site_description' => '视频妈影院，最新高清超清电影电视剧片在线下载',
    'template_dir' => 'ak',
    'mob_template_dir' => 'stui_tpl',
    'html_dir' => '755175813',
    'ads_dir' => '',
  ),
);
?>