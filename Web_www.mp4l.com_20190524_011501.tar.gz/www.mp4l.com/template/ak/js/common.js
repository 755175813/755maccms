/*!
 * =====================================================
 * 懒加载组件
 * =====================================================
 */
window.Echo=(function(window,document,undefined){'use strict';var store=[],offset,throttle,poll;var _inView=function(el){var coords=el.getBoundingClientRect();return((coords.top>=0&&coords.left>=0&&coords.top)<=(window.innerHeight||document.documentElement.clientHeight)+parseInt(offset));};var _pollImages=function(){for(var i=store.length;i--;){var self=store[i];if(_inView(self)){self.src=self.getAttribute('data-echo');store.splice(i,1);}}};var _throttle=function(){clearTimeout(poll);poll=setTimeout(_pollImages,throttle);};var init=function(obj){var nodes=document.querySelectorAll('[data-echo]');var opts=obj||{};offset=opts.offset||0;throttle=opts.throttle||250;for(var i=0;i<nodes.length;i++){store.push(nodes[i]);}_throttle();if(document.addEventListener){window.addEventListener('scroll',_throttle,false);}else{window.attachEvent('onscroll',_throttle);}};return{init:init,render:_throttle};})(window,document);
/*!
 * =====================================================
 * 自动调整占位
 * =====================================================
 */
//================调整幻灯片自动占位================//
function Islide(){
	var w = $("body").width();
	var width = parseInt(w * 1);
	var height = parseInt(360 * (w / 640));
	$(".resize").css({
		"height": height
	});
}
//================调整列表自动占位================//
function resizeImgCommon() {
	var arg = arguments[0] || "resize_list";
	var width = $("." + arg).width();
	height = $("." + arg).height();
	var posWidth = arguments[1] || 195;
	var posHeight = arguments[2] || 260;
	var pos = arguments[3] || 0.33;
	width = parseInt(width / 3);
	height = parseInt(posHeight * (width / posWidth));
	$("." + arg + " img").css({
		"width": width,
		"height": height
	});
	arg == "resize_list" && $("." + arg + " .pic").css({
		"width": width,
		"height": height
	})
}
//================调整专题================//
function specialImgCommon() {
	var arg = arguments[0] || "special_list";
	var width = $("." + arg).width();
	height = $("." + arg).height();
	var posWidth = arguments[1] || 240;
	var posHeight = arguments[2] || 126;
	var pos = arguments[3] || 0.5;
	width = parseInt(width / 2);
	height = parseInt(posHeight * (width / posWidth));
	$("." + arg + " img").css({
		"width": width,
		"height": height
	});
	arg == "special_list" && $("." + arg + " .pic").css({
		"width": width,
		"height": height
	})
}
window.onload = function(){
	$(".zui-action-back").click(function(){//后退一步
		javascript:history.go(-1);
	});
}
function goname(id){
	var top = $("#"+id).offset().top;
	$("body,html").scrollTop(top);
}
var MAC={
	'Url': document.URL,
	'Title': document.title,
	'Cookie': {
		'Set': function(name,value,days){
			var exp = new Date();
			exp.setTime(exp.getTime() + days*24*60*60*1000);
			var arr=document.cookie.match(new RegExp("(^| )"+name+"=([^;]*)(;|$)"));
			document.cookie=name+"="+escape(value)+";path=/;expires="+exp.toUTCString();
		},
		'Get': function(name){
			var arr = document.cookie.match(new RegExp("(^| )"+name+"=([^;]*)(;|$)"));
			if(arr != null){ return unescape(arr[2]); return null; }
		},
		'Del': function(name){
			var exp = new Date();
			exp.setTime(exp.getTime()-1);
			var cval = this.Get(name);
			if(cval != null){ document.cookie = name+"="+escape(cval)+";path=/;expires="+exp.toUTCString(); }
		}
	},
	'Hits':function(tab,id){//点击量
		$.get(SitePath+"inc/ajax.php?ac=hits&tab="+tab+"&id="+id,function(r){$('#hits').html(r);});
	},
}
