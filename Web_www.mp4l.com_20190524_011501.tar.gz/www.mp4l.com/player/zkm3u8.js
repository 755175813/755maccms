MacPlayer.Html = '<iframe width="100%" height="'+MacPlayer.Height+'" class="embed-responsive-item" src="http://cj.zuikzy.com/m3u8.php?url='+MacPlayer.PlayUrl+'" frameborder="0" border="0" marginwidth="0" marginheight="0" scrolling="no"></iframe>';
MacPlayer.Show();
