MacPlayer.Html = '<iframe width="100%" height="'+MacPlayer.Height+'" src="https://www.ixxplayer.com/video.php?url='+MacPlayer.PlayUrl+'" frameborder="0" allowfullscreen></iframe>';

MacPlayer.Show();