$(function(){
    webck();
    function webck(){
        $.post("webcheck.php",{
        mp:'web'
    },function(dunling){
      var mpweb = dunling.split("@dunling@");
      var jiaoyanma = mpweb['1'];
      var liulanqx = mpweb['0'];
      if(liulanqx=="0"){
        $(".jiaoyanma").text(jiaoyanma);
        return false;
      }
      if(liulanqx=="1"){
      $("#dunling_web_bg").hide();
      $("#dunling_web_alert").hide();
      }
    }); 
    
}
    var visiblewidth = $(window).width();
    var visibleheight = $(window).height();
    $("#dunling_web_alert").css("left",(visiblewidth-300)/2 + 'px');
    $("#dunling_web_alert").css("top",(visibleheight-500)/2 + 'px');
    $(window).resize(function(){
    var visiblewidth = $(window).width();
    var visibleheight = $(window).height();
    $("#dunling_web_alert").css("left",(visiblewidth-300)/2 + 'px');
    $("#dunling_web_alert").css("top",(visibleheight-500)/2 + 'px');
    });

setInterval(function(){
   webck();
},2000);
});