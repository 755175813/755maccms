<?php
ini_set("error_reporting","E_ALL & ~E_NOTICE");
/**
  * wechat php test
  */

//define your token
//weixinabc是一个token,是一个令牌
define("TOKEN", "weixin");
$wechatObj = new wechatCallbackapiTest();

    $wechatObj->responseMsg();
  //$wechatObj->valid();
//exit;

class wechatCallbackapiTest
{
	public function valid()
    {
        $echoStr = $_GET["echostr"];


        if($this->checkSignature()){
        	echo $echoStr;
        	exit;
        }
    }


    public function responseMsg()
    {

		$postStr = isset($GLOBALS["HTTP_RAW_POST_DATA"])?$GLOBALS["HTTP_RAW_POST_DATA"]:"";


		if (!empty($postStr)){

                libxml_disable_entity_loader(true);
              	$postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
                $fromUsername = $postObj->FromUserName;
                $toUsername = $postObj->ToUserName;
                $keyword = trim($postObj->Content);

				$event = $postObj->Event;			
                $time = time();
                $textTpl = "<xml>
							<ToUserName><![CDATA[%s]]></ToUserName>
							<FromUserName><![CDATA[%s]]></FromUserName>
							<CreateTime>%s</CreateTime>
							<MsgType><![CDATA[%s]]></MsgType>
							<Content><![CDATA[%s]]></Content>
							<FuncFlag>0</FuncFlag>
							</xml>";    
				


				switch($postObj->MsgType)
				{
					case 'event':

						if($event == 'subscribe')
						{
						//关注后的回复
												$contentStr = "";


							$msgType = 'text';
							$textTpl = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
							echo $textTpl;

						}
						break;
					case 'text':
						if(preg_match('/[\x{4e00}-\x{9fa5}]+/u',$keyword))
						{	

							$newsTplHeader = "<xml>
							<ToUserName><![CDATA[%s]]></ToUserName>
							<FromUserName><![CDATA[%s]]></FromUserName>
							<CreateTime>%s</CreateTime>
							<MsgType><![CDATA[news]]></MsgType>
							<ArticleCount>%s</ArticleCount>
							<Articles>";

							$newsTplItem = "<item>
							<Title><![CDATA[%s]]></Title> 
							<Description><![CDATA[%s]]></Description>
							<PicUrl><![CDATA[%s]]></PicUrl>
							<Url><![CDATA[%s]]></Url>
							</item>";
							$newsTplFooter="</Articles>
							</xml>";
 
									$con = mysql_connect("localhost","sql1_mp4l_com","kim755175813");								
									mysql_query("SET NAMES UTF8");
									mysql_query("set character_set_client=utf8"); 
									mysql_query("set character_set_results=utf8");
									mysql_select_db("sql1_mp4l_com", $con);
									$sql = "SELECT * FROM `mac_vod` WHERE `d_name` like '%".$keyword."%'  LIMIT 0 , 8";

									$result = mysql_query($sql);
									$itemCount = 0;
								if(mysql_num_rows($result)>0){
								while($row = mysql_fetch_assoc($result))
								{

									$title = "".$row['d_name']."";
									$des ="";
									$url ="http://www.kanjuba.tw/vod-detail-id-".$row['d_id'].".html";

									

									$pic = strstr($row['d_pic'], 'http');

									if($pic){

									

									$picUrl1=$row['d_pic'];

									}else{

									

									$picUrl1 ="http://42mj.com/".$row['d_pic']."";

									}



									



									$contentStr .= sprintf($newsTplItem, $title, $des, $picUrl1, $url);																													



									++$itemCount;	



								}							



								$newsTplHeader = sprintf($newsTplHeader, $fromUsername, $toUsername, $time, $itemCount);



								$resultStr =  $newsTplHeader. $contentStr. $newsTplFooter;



								echo $resultStr; 



								}



								else



								{									$newsTpl = "<xml>
										<ToUserName><![CDATA[%s]]></ToUserName>
										<FromUserName><![CDATA[%s]]></FromUserName>
										<CreateTime>%s</CreateTime>
										<MsgType><![CDATA[news]]></MsgType>
										<ArticleCount>1</ArticleCount>
										<Articles>
										<item>
										<Title><![CDATA[%s]]></Title> 
										<Description><![CDATA[%s]]></Description>
										<PicUrl><![CDATA[%s]]></PicUrl>
										<Url><![CDATA[%s]]></Url>
										</item>							
										</Articles>
										</xml>";						
								
								//没有查找到的时候的回复
										$title = '居然没有，少回复几个字试试，或者点这个图文告诉我需要更新的电影名字！';
										
										$des1 ="";
										
										$picUrl1 ="http://wx2.sinaimg.cn/mw690/0060lm7Tly1fs9vmjspnoj30p00dwaax.jpg";
										
										$url="http://wpa.qq.com/msgrd?v=3&uin=755175813&site=125.la&Menu=yes/";

										$resultStr= sprintf($newsTpl, $fromUsername, $toUsername, $time, $title, $des1, $picUrl1, $url) ;
									
										echo $resultStr; 	

								}
										mysql_close($con);
									
								}																		
						else
						{
							$newsTpl = "<xml>
							<ToUserName><![CDATA[%s]]></ToUserName>
							<FromUserName><![CDATA[%s]]></FromUserName>
							<CreateTime>%s</CreateTime>
							<MsgType><![CDATA[news]]></MsgType>
							<ArticleCount>1</ArticleCount>
							<Articles>
							<item>
							<Title><![CDATA[%s]]></Title> 
							<Description><![CDATA[%s]]></Description>
							<PicUrl><![CDATA[%s]]></PicUrl>
							<Url><![CDATA[%s]]></Url>
							</item>							
							</Articles>
							</xml>";	
 						if($keyword=="a")
						{
										$title = '电影目录：点击进入';
										
										$des1 ="";
										//图片地址
										$picUrl1 ="http://wx2.sinaimg.cn/mw690/0060lm7Tly1fs9vmjspnoj30p00dwaax.jpg";
										//跳转链接
										$url="http://123.400mk.com//?m=vod-type-id-1.html";

										$resultStr= sprintf($newsTpl, $fromUsername, $toUsername, $time, $title, $des1, $picUrl1, $url) ;
									
										echo $resultStr; 	
						}
						if($keyword=="b")
						{
										$title = '电视剧目录：点击进入';
										
										$des1 ="";
										//图片地址
										$picUrl1 ="http://wx2.sinaimg.cn/mw690/0060lm7Tly1fs9vmjspnoj30p00dwaax.jpg";
										//跳转链接
										$url="http://123.400mk.com//?m=vod-type-id-2.html";

										$resultStr= sprintf($newsTpl, $fromUsername, $toUsername, $time, $title, $des1, $picUrl1, $url) ;
									
										echo $resultStr; 	
						}
						if($keyword=="c")
						{
										$title = '综艺目录：点击进入';
										
										$des1 ="";
										//图片地址
										$picUrl1 ="http://wx2.sinaimg.cn/mw690/0060lm7Tly1fs9vmjspnoj30p00dwaax.jpg";
										//跳转链接
										$url="http://123.400mk.com//?m=vod-type-id-3.html";

										$resultStr= sprintf($newsTpl, $fromUsername, $toUsername, $time, $title, $des1, $picUrl1, $url) ;
									
										echo $resultStr; 	
						}
						if($keyword=="d")
						{
										$title = '爱情目录：点击进入';
										
										$des1 ="";
										//图片地址
										$picUrl1 ="http://wx2.sinaimg.cn/mw690/0060lm7Tly1fs9vmjspnoj30p00dwaax.jpg";
										//跳转链接
										$url="http://123.400mk.com//?m=vod-type-id-7.html";

										$resultStr= sprintf($newsTpl, $fromUsername, $toUsername, $time, $title, $des1, $picUrl1, $url) ;
									
										echo $resultStr; 	
						}
						if($keyword=="e")
						{
										$title = '电视直播：点击进入';
										
										$des1 ="";
										//图片地址
										$picUrl1 ="http://wx2.sinaimg.cn/mw690/0060lm7Tly1fs9vmjspnoj30p00dwaax.jpg";
										//跳转链接
										$url="http://mp.weixin.qq.com/s/-v-XneAOYAaxQOMOexWQVQ";

										$resultStr= sprintf($newsTpl, $fromUsername, $toUsername, $time, $title, $des1, $picUrl1, $url) ;
									
										echo $resultStr; 	
						}
												$contentStr = "英文不支持公众号内搜索，请到网站首页进行搜索";


							$msgType = 'text';
							$resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
							echo $resultStr;
						}					
						
						
						break;
					default:
						break;
				}						

        }else {
        	echo "哈哈";
        	exit;
        }
    }
		
	private function checkSignature()
	{
        // you must define TOKEN by yourself
        if (!defined("TOKEN")) {
            throw new Exception('TOKEN is not defined!');
        }
        
        $signature = $_GET["signature"];
        $timestamp = $_GET["timestamp"];
        $nonce = $_GET["nonce"];
        		
		$token = TOKEN;
		$tmpArr = array($token, $timestamp, $nonce);
        // use SORT_STRING rule
		sort($tmpArr, SORT_STRING);
		$tmpStr = implode( $tmpArr );
		$tmpStr = sha1( $tmpStr );
		
		if( $tmpStr == $signature ){
			return true;
		}else{
			return false;
		}
	}
}

?>