//即生效开始弹窗 更换二维码微信号等 仔细阅读的下方参数说明 如需关闭，直接在第二行开始添加上 
 var ewm = [
    ["kuguatv", "http://open.weixin.qq.com/qr/code?username=kuguatv", "https://mp.weixin.qq.com/s?__biz=MzU3NjA2MDc0OA==&mid=100004899&idx=1&sn=101751dcbee83b7ed5f18ce4a7e882bb&chksm=7d18f8004a6f711670d08a305dd9c7122aeddf1dc5dbe7c6f26eb755347da5a9f802d811d7ec#rd"] //三个参数 第一个微信号 第二个 图片地址 第三个 关注页
];
shu = ewm.length;
sx = parseInt(Math.random() * shu);
var tan = ewm[sx];

function appendText() {
    var txt = '<section id="fade" style="display: none;position: fixed;top: 0%;left: 0%;background-color: black;z-index:99999;-moz-opacity: 0.8;opacity:.80;filter: alpha(opacity=80);"></section><section id="MyDiv" style="display: none;width: 100%;height: 100%;position: fixed;top: 0%;left: 0%;width: 100%;background-color: black;z-index:999999;overflow: auto;-moz-opacity: 0.9;opacity:.90;filter: alpha(opacity=90);"><section style="text-align: right;height: 32px;">  <span style="display:block;font-size: 14px; color:white;width:48px;text-align:center;float:right; margin-top:0.4rem;margin-right: 10px" id="cl">关闭</span></section><section style="margin:0 auto;width:100%;-moz-opacity: 1;opacity:1;filter: alpha(opacity=100);"><ul style="list-style-type:none;color:white;text-align: center;"><li style="font-size:0.35rem; margin-left:1.2rem;padding-bottom:0.1rem;">长按识别二维码</li><li style="font-size:0.35rem;padding-bottom:0.1rem;">关注官方公众号，随时取得联系</li><li style="padding-bottom:0.5rem;"><img style="width:6rem;" src="' + tan[1] + '"></li><li style="font-size:0.35rem;padding-bottom:0.1rem;">无法识别请添加公众号：' + tan[0] + '</li><li style="font-size:0.35rem;padding-bottom:0.1rem;"></li><li style="font-size:0.35rem;padding-bottom:0.1rem;margin-top: 1em;">  <a id="go" style="text-decoration: none;display: inline-block;color: #fff;font-size: 24px;padding: 8px;border-radius: 8px;text-align: center;background-color: #E8530B">点击马上关注</a></li><li style="padding-bottom:0.5rem;"></li><ul></section></section>';
    $("body").prepend(txt);
}
appendText();
//弹出隐藏层
function ShowDiv(show_div, bg_div) {
    document.getElementById(show_div).style.display = 'block';
    document.getElementById(bg_div).style.display = 'block';
    var bgdiv = document.getElementById(bg_div);
    bgdiv.style.width = document.body.scrollWidth;
    $("#" + bg_div).height($(document).height());
};

function CloseDiv(show_div, bg_div) {
    document.getElementById(show_div).style.display = 'none';
    document.getElementById(bg_div).style.display = 'none';
};

function setcookie() {
    var Then = new Date()
    Then.setTime(Then.getTime() + 1000 * 60 * 60 * 2);
    var cookieString = new String(document.cookie)
    var cookieHeader = "AdsFileter";
    document.cookie = cookieHeader + "=1;expires=" + Then.toGMTString() + ';path=/;';
}

var cS = new String(document.cookie);
var cH = "AdsFileter";
var bP = cS.indexOf(cH);
if (bP == -1) {
    ShowDiv('MyDiv', 'fade');
    $('html,body').animate({ scrollTop: '0px' }, 100);
    setcookie();
}
$("#cl").click(function() {
    $("#MyDiv").hide();
    $("#fade").hide();
    setcookie();
});
$("#q").click(function() {
    $("#MyDiv").hide();
    $("#fade").hide();
    setcookie();
});
$("#go").click(function() {
    setcookie();
    window.location.href = tan[2];
});