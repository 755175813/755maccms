function dalert(){
	var returnVal = window.confirm("【通知】未满18岁请立即关闭页面！
                                   已满18岁请点取消", "【提示】");
	if(returnVal){
			 window.location.href="http://www.dushe.tw/400mk";
	}
}
setTimeout('dalert()',500);