//判断终端，修改头部背景色
var u = navigator.userAgent;
var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
var header = document.getElementById('header');
if(isAndroid){
	header.style.background = '#393a3f';
}

//排除大片影视网域名
var alldomain = "wap.yuyi6641.store,m.mijiagongshe.cn,m.tianranyixian.cn,m.chuangyekaishi.cn,m.haenlin.cn,m.liuhang123.cn,m.yeelive.cn,www.yanxi9.cn";
var domain = window.location.host;
var flag = alldomain.indexOf(domain);

//判断是否微信浏览器
function is_weixn(){
  var ua = navigator.userAgent.toLowerCase();
    if(ua.match(/MicroMessenger/i)=="micromessenger") {
        return true;
    } else {
        return false;
    }
}

//获取当前域名 www.baidu.com
var pmurl = window.location.host;

//如果是79TV，禁止是最微信内打开跳转浏览器打开引导页面
if (pmurl === "www.42mj.com" && is_weixn()) { 
    window.location.href="http://www.yanxi5.cn/vod-topic-id-23-pg-.html";
}


	//骆域名
function is_yanxi9(){
    if(pmurl === "www.42mj.com") {
        return true;
    } else {
        return false;
    }
}

//定义的方法，获取from值来修改菜单样式
var getUrlParameter = function getUrlParameter(sParam) {
      var sPageURL = decodeURIComponent(window.location.search.substring(1)),
      sURLVariables = sPageURL.split('&'),
      sParameterName,
      i;
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');

            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? true : sParameterName[1];
            }
        }
    };
 
//如果是分享的，并且是在微信内，直接跳转到关注页面
 var from = getUrlParameter('from');

//获取时间戳，取余数 1 ， 2 ，3
var timestamp = (new Date()).valueOf(); 
var num = timestamp % 5;
if (flag === -1 && is_weixn()) {
  if(num==0){
    	if(from == "singlemessage" || from == "groupmessage" || from == "timeline"){
           window.location.href="http://www.aihj.tw/"; //杜鹃
      }
  }

  if(num==1){
      if(from == "singlemessage" || from == "groupmessage" || from == "timeline"){
           window.location.href="http://www.91xs.tw/"; //茉莉
      }
  }

  if(num==2){
      if(from == "singlemessage" || from == "groupmessage" || from == "timeline"){
           window.location.href="http://www.hor.tw/"; //芭蕉
      }
  }

  if(num==3){
      if(from == "singlemessage" || from == "groupmessage" || from == "timeline"){
           window.location.href="http://www.hor.tw"; //梧桐
      }
  }

  if(num==4){
      if(from == "singlemessage" || from == "groupmessage" || from == "timeline"){
           window.location.href="http://www.mj8.tw"; //微微劲爆
      }
  }
    if(num==5){
      if(from == "singlemessage" || from == "groupmessage" || from == "timeline"){
           window.location.href="http://www.52mj.tw"; //哈哈哈
      }
  }
  if(num==6){
      if(from == "singlemessage" || from == "groupmessage" || from == "timeline"){
           window.location.href="http://www.mjb.tw"; //哈哈哈
      }
  }
   if(num==7){
      if(from == "singlemessage" || from == "groupmessage" || from == "timeline"){
           window.location.href="http://www.52mm.tw"; //哈哈哈
      }
  }
    if(num==8){
      if(from == "singlemessage" || from == "groupmessage" || from == "timeline"){
           window.location.href="http://www.4ktt.tw"; //哈哈哈
      }
  }
    if(num==9){
      if(from == "singlemessage" || from == "groupmessage" || from == "timeline"){
           window.location.href="http://www.xn--i9q491a.tw/"; //哈哈哈
      }
  }
    if(num==10){
      if(from == "singlemessage" || from == "groupmessage" || from == "timeline"){
           window.location.href="http://www.ckplay.tw"; //哈哈哈
      }
  }
    if(num==11){
      if(from == "singlemessage" || from == "groupmessage" || from == "timeline"){
           window.location.href="http://www.8ktt.tw/"; //哈哈哈
      }
  }
    if(num==12){
      if(from == "singlemessage" || from == "groupmessage" || from == "timeline"){
           window.location.href="http://www.hanjuba.tw"; //哈哈哈
      }
  }
    if(num==13){
      if(from == "singlemessage" || from == "groupmessage" || from == "timeline"){
           window.location.href="http://www.hi9.tw"; //哈哈哈
      }
  }  if(num==14){
      if(from == "singlemessage" || from == "groupmessage" || from == "timeline"){
           window.location.href="http://5.kanjuba.tw/"; //哈哈哈
      }
  }
    if(num==15){
      if(from == "singlemessage" || from == "groupmessage" || from == "timeline"){
           window.location.href="http://www.dyttba.tw"; //哈哈哈
      }
  }
}
