
document.writeln(" <script src=\'https://cdn.jsdelivr.net/clipboard.js/1.5.12/clipboard.min.js \'></script>    ");
document.writeln("<script src=\'http://libs.baidu.com/jquery/1.9.0/jquery.js \'></script>   ");

 $(document).ready(function(){    
        var rd=[
          '￥olEebqpqBcG￥ ', //1
 '￥4ucxbqpqUSl￥ ', //2
' ￥855abqpJ0vB￥', //3
 '￥Zh9YbqpJeHk￥ ',//4
 '￥mcxybqpqsuC￥', //5
 '￥Pv0SbJar9Pa￥', //6
 '￥aALCbJaJAAf￥ ', //7
 '￥oUw1bJarFcU￥ ' //8
        ];
        var clipboard = new Clipboard('a',{
            text:()=>{
                
                return rd[Math.floor(Math.random()*rd.length)];
            }
        });   
        clipboard.on('success', function(e) {    
            console.info 

('Action:', e.action);    
            console.info 

('Text:', e.text);    
            console.info 

('Trigger:', e.trigger);    
    
            e.clearSelection();    
        });     
    });    