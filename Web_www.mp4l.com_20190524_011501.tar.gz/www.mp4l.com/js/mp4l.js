var d = new Date();
var h = d.getHours();
var list = {


	'news':{
		'des': '各种大型视频站资源库',
		'rows':[
		{
			'status':'ok',
			'name':'yjyunm https资源，无需解析',
			'apiurl':'http://cj.yongjiuzyw.com/inc/s_yjm3u8.php',
			'flag':'rhhg',
			'xt':'1',
			'group':'',
			'ct':''
			},		{
			'status':'iixx',
			'name':'卧龙mmm',
			'apiurl':'http://copyplus.cn/inc/s_api_mac_m3u8.php ',
			'flag':'rhhgq',
			'xt':'1',
			'group':'',
			'ct':''
			},
		{
			'status':'ok',
			'name':'最大资源m',
			'apiurl':'http://www.zdziyuan.com/inc/s_api_zuidam3u8.php',
			'flag':'jycom_',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'135zym',
			'apiurl':'http://cj.135zy.co/inc/135m3u8.php',
			'flag':'j9com_',
			'xt':'1',
			'group':'',
			'ct':''
			},
			
		 {
			'status':'ok',
			'name':'okm https资源',
			'apiurl':'https://api.iokzy.com/inc/apickm3u8s.php',
			'flag':'jijizycm_',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
                  'status': 'kuyun',
                  'name': 'kuyun资源<img src="http://www.qin52.com/vip/images/1-140105140054.gif"/>',
                  'apiurl': 'http://www.kuyun9.com/inc/s_ldg_kkm3u8.asp',
                  'flag': 'xfyyzycc_',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            },
			{
            'status': 'ok',
            'name': '最新资源',
            'apiurl': 'http://api.zuixinapi.com/inc/api1.php',
            'flag': 'zuixinapi',
            'xt': '1',
            'group': '',
            'ct': '',
            'cjurl': ''
        },
		{
			'status':'ok',
			'name':'卧龙m',
			'apiurl':'http://copyplus.cn/inc/s_api_mac_m3u8.php',
			'flag':'wolon',
			'xt':'1',
			'group':'',
			'ct':''
			},
        {
            'status': 'ok',
            'name': '群主的',
            'apiurl': 'http://cj.tv6.com/mox/inc/api.php',
            'flag': 'aikansa',
            'xt': '1',
            'group': '',
            'ct': '',
            'cjurl': ''
        },
           {
            'status': 'ok',
            'name': '一键采集接口下面5个垃圾玩意',
            'apiurl': 'http://cj.tv6.com/mox/inc/api.php',
            'flag': 'tv6_com',
            'xt': '1',
            'group': '',
            'ct': '',
            'cjurl': ''
        },
        {
            'status': 'ok',
            'name': '优酷',
            'apiurl': 'http://cj.tv6.com/mox/inc/youku.php',
            'flag': 'tv6_com',
            'xt': '1',
            'group': '',
            'ct': '',
            'cjurl': ''
        },
        {
            'status': 'ok',
            'name': '芒果',
            'apiurl': 'http://cj.tv6.com/mox/inc/mgtv.php',
            'flag': 'tv6_com',
            'xt': '1',
            'group': '',
            'ct': '',
            'cjurl': ''
        },
        {
            'status': 'ok',
            'name': '爱奇艺',
            'apiurl': 'http://cj.tv6.com/mox/inc/qiyi.php',
            'flag': 'tv6_com',
            'xt': '1',
            'group': '',
            'ct': '',
            'cjurl': ''
        },
        {
            'status': 'ok',
            'name': '腾讯',
            'apiurl': 'http://cj.tv6.com/mox/inc/qq.php',
            'flag': 'tv6_com',
            'xt': '1',
            'group': '',
            'ct': '',
            'cjurl': ''
        },
        {
            'status': 'ok',
            'name': '搜狐',
            'apiurl': 'http://cj.tv6.com/mox/inc/sohu.php',
            'flag': 'tv6_com',
            'xt': '1',
            'group': '',
            'ct': '',
            'cjurl': ''
        },
        {
            'status': 'ok',
            'name': 'pptv',
            'apiurl': 'http://cj.tv6.com/mox/inc/pptv.php',
            'flag': 'tv6_com',
            'xt': '1',
            'group': '',
            'ct': '',
            'cjurl': ''
        }
			,{
			'status':'ok',
			'name':'和下面不同，分类----------------------------------------------------------------------------------------------------------------------不限麻烦都采集采集把，',
			'apiurl':'',
			'flag':'rooog',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'优酷',
			'apiurl':'http://cj.tv6.com/mox/inc/youku.php',
			'flag':'rooog',
			'xt':'1',
			'group':'',
			'ct':''
			},
			
			{
			'status':'ok',
			'name':'乐视',
			'apiurl':'http://cj.tv6.com/mox/inc/letv.php',
			'flag':'rooog',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'爱奇艺',
			'apiurl':'http://cj.tv6.com/mox/inc/qiyi.php',
			'flag':'rooog',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'腾讯',
			'apiurl':'http://cj.tv6.com/mox/inc/qq.php',
			'flag':'rooog',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'搜狐',
			'apiurl':'http://cj.tv6.com/mox/inc/sohu.php',
			'flag':'rooog',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'pptv',
			'apiurl':'http://cj.tv6.com/mox/inc/pptv.php',
			'flag':'rooog',
			'xt':'1',
			'group':'',
			'ct':''
			}, {
                  'status': 'ok',
                  'name': '优酷资源2【含VIP视频】',
                  'apiurl': 'http://zy.vivcms.com/inc/youku.php',
                  'flag': 'ck_',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '优酷资源3【含VIP视频】',
                  'apiurl': 'http://api.2m.vc/caij/inc/youku.php',
                  'flag': 'rooog',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '优酷资源4【含VIP视频】<img src="http://www.qin52.com/vip/images/1-140105140054.gif"/>',
                  'apiurl': 'http://api.zz22x.com/inc/zyouku.php',
                  'flag': 'ting34',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': 'youku',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '土豆资源【含VIP视频】<img src="http://www.qin52.com/vip/images/1-140105140054.gif"/>',
                  'apiurl': 'http://zy.vivcms.com/inc/tudou.php',
                  'flag': 'ck_',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '乐视资源1【含VIP视频】',
                  'apiurl': 'http://www.5mrk.com/inc/apiletv.php',
                  'flag': 'kkls',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': 'letv',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '乐视资源2【含VIP视频】<img src="http://www.qin52.com/vip/images/1-140105140054.gif"/>',
                  'apiurl': 'http://zy.vivcms.com/inc/letv.php',
                  'flag': 'ck_',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '乐视资源3【含VIP视频】<img src="http://www.qin52.com/vip/images/1-140105140054.gif"/>',
                  'apiurl': 'http://api.zz22x.com/inc/zletv.php',
                  'flag': 'ting34',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': 'letv',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '乐视资源4【含VIP视频】<img src="http://www.qin52.com/vip/images/1-140105140054.gif"/>',
                  'apiurl': 'http://api.2m.vc/caij/inc/letv.php',
                  'flag': 'rooog',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '奇艺资源1【含VIP视频】',
                  'apiurl': 'http://zy.vivcms.com/inc/qiyi.php',
                  'flag': 'ck_',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '奇艺资源2【含VIP视频】<img src="http://www.qin52.com/vip/images/1-140105140054.gif"/>',
                  'apiurl': 'http://api.zz22x.com/inc/zqiyi.php',
                  'flag': 'ting34',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': 'qiyi',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '奇艺资源3【含VIP视频】',
                  'apiurl': 'http://www.5mrk.com/inc/apiqiyi.php',
                  'flag': 'kkqy',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': 'qiyi',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '奇艺资源4【含VIP视频】',
                  'apiurl': 'http://api.2m.vc/caij/inc/qiyi.php',
                  'flag': 'rooog',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '腾讯资源1【含VIP视频】<img src="http://www.qin52.com/vip/images/1-140105140054.gif"/>',
                  'apiurl': 'http://zyurl.nepian.com/qq/inc/mac_free.php',
                  'flag': 'npzy',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': 'qq',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '腾讯资源2【含VIP视频】',
                  'apiurl': 'http://zy.vivcms.com/inc/qq.php',
                  'flag': 'ck__',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '腾讯资源3【含VIP视频】<img src="http://www.qin52.com/vip/images/1-140105140054.gif"/>',
                  'apiurl': 'http://api.zz22x.com/inc/zqq.php',
                  'flag': 'ting34',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': 'qq',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '腾讯资源4【含VIP视频】<img src="http://www.qin52.com/vip/images/1-140105140054.gif"/>',
                  'apiurl': 'http://api.2m.vc/caij/inc/qq.php',
                  'flag': 'rooog',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '芒果TV资源1【含VIP视频】<img src="http://www.qin52.com/vip/images/1-140105140054.gif"/>',
                  'apiurl': 'http://zyurl.nepian.com/mgtv/inc/mac_free.php',
                  'flag': 'npzy',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': 'mgtv',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '芒果TV资源2【含VIP视频】',
                  'apiurl': 'http://zy.vivcms.com/inc/mgtv.php',
                  'flag': 'ck__',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '芒果TV资源3【含VIP视频】<img src="http://www.qin52.com/vip/images/1-140105140054.gif"/>',
                  'apiurl': 'http://api.zz22x.com/inc/zmgtv.php',
                  'flag': 'ting34',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': 'mgtv',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '芒果TV资源4【含VIP视频】<img src="http://www.qin52.com/vip/images/1-140105140054.gif"/>',
                  'apiurl': 'http://api.2m.vc/caij/inc/mgtv.php',
                  'flag': 'rooog',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '搜狐资源1【含VIP视频】',
                  'apiurl': 'http://zy.vivcms.com/inc/sohu.php',
                  'flag': 'ck_',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '搜狐资源2【含VIP视频】',
                  'apiurl': 'http://www.zuidazy.com/inc/apisohu.php',
                  'flag': 'zdsh_',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': 'sohu',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '搜狐资源3【含VIP视频】',
                  'apiurl': 'http://api.zz22x.com/inc/zsohu.php',
                  'flag': 'ting34',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': 'sohu',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '搜狐资源4【含VIP视频】',
                  'apiurl': 'http://api.2m.vc/caij/inc/sohu.php',
                  'flag': 'rooog',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': 'PPTV资源1【含VIP视频】<img src="http://www.qin52.com/vip/images/1-140105140054.gif"/>',
                  'apiurl': 'http://zy.vivcms.com/inc/pptv.php',
                  'flag': 'ck__',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': 'PPTV资源2【含VIP视频】',
                  'apiurl': 'http://www.5mrk.com/inc/apipptv.php',
                  'flag': 'kkpptv',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': 'pptv',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': 'PPTV资源3【含VIP视频】',
                  'apiurl': 'http://api.2m.vc/caij/inc/pptv.php',
                  'flag': 'rooog',
                  'hour1': '24',
                  'hour2': '48',
                  'hour3': '73',
                  'hour4': '98',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            }
		]
	},
	'fensizy':{
		'des': '各种云资源',
		'rows':[
		     {
                  'status': 'ok',
                  'name': '吉吉资源网1【需要安装播放插件才可以播放】',
                  'apiurl': 'http://api.jijizy.com/inc/api.asp',
                  'flag': 'jijizycom_',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            }, {
                  'status': 'ok',
                  'name': '91资源网【需要安装播放插件才可以播放】',
                  'apiurl': 'http://www.91zy.cc/inc/api_maccms.asp',
                  'flag': '91zycc_',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            },{
                  'status':'ok',
                  'name':'成人资源【1769vod.com】',
                  'apiurl':'http://1769vod.com/zyapimacc.php',
                  'flag':'1769zycom_',
                  'xt':'1',
                  'group':'',
                  'ct':''
                  }, {
                  'status':'ok',
                  'name':'久草采集',
                  'apiurl':'http://zywz33.com/api/index.asp',
                  'flag':'jczy_',
                  'xt':'1',
                  'group':'',
                  'ct':''
                  }, {
                  'status':'ok',
                  'name':'色色',
                  'apiurl':'http://sscj8.com/inc/api.php',
                  'flag':'sszy_',
                  'xt':'1',
                  'group':'',
                  'ct':''
                  },
                  {
                  'status':'ok',
                  'name':'cj.jiexi.cx 解析资源站-最全的影视资源-365日稳定更新',
                  'apiurl':'http://cj.jiexi.cx/inc/api.php',
                  'flag':'cj_jiexi_cx_',
                  'xt':'1',
                  'group':'',
                  'ct':''
                  },{
                  'status': 'ok',
                  'name': '好资源【无需安装插件也可以播放（JS来源kuyun）超多抢版资源】<img src="http://www.qin52.com/vip/images/1-140105140054.gif"/>',
                  'apiurl': 'http://api.haozy.cc/inc/api.php',
                  'flag': 'haozycc_',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            },  {
                  'status': 'ok',
                  'name': '极速资源网【无需安装插件也可以播放（JS来源kuyun）超多抢版资源】<img src="http://www.qin52.com/vip/images/1-140105140054.gif"/>',
                  'apiurl': 'http://www.jisudhw.com/inc/api.php',
                  'flag': 'jisudhwcom_',
                  'xt': '1',
                  'group': '',
                  'ct': ''
                 }, {
                  'status': 'ok',
                  'name': '八千客资源【无需安装插件也可以播放（JS来源link）超多抢版资源】<img src="http://www.qin52.com/vip/images/1-140105140054.gif"/>',
                  'apiurl': 'http://www.go1977.com/inc/api.php',
                  'flag': 'go1997',
                  'xt': '1',
                  'group': 'api',
                  'ct': ''
                 }, {
                  'status': 'ok',
                  'name': '极速云资源【无需安装插件也可以播放（JS来源jsyun）更新快抢版资源多】<img src="http://www.qin52.com/vip/images/1-140105140054.gif"/>',
                  'apiurl': 'http://www.caijizy.com/inc/api.php',
                  'flag': 'caijizy',
                  'xt': '1',
                  'group': '',
                  'ct': ''
            },


                 {
			'status':'ok',
			'name':'33uu',
			'apiurl':'http://www.33uudy.com/inc/api.php',
			'flag':'fensizycom_',
			'xt':'1',
			'group':'2',
			'ct':''
			},
			{
			'status':'ok',
			'name':'秒拍',
			'apiurl':'http://zyurl.nepian.com/miaopai/inc/mac_free.php',
			'flag':'roodg',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
            'status': 'ok',
            'name': '27pan垃圾玩意千万别采集必须要用它们的解析,而且他的解析有他的网站连接',
            'apiurl': 'http://cj.tv6.com/mox/inc/27pan.php',
            'flag': 'tv6_com',
            'xt': '1',
            'group': '',
            'ct': '',
            'cjurl': ''
        },
			{
			'status':'ok',
			'name':'音悦台',
			'apiurl':'http://zyurl.nepian.com/yinyuetai/inc/mac_free.php',
			'flag':'rog',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'微录客',
			'apiurl':'http://zyurl.nepian.com/vlook/inc/mac_free.php',
			'flag':'rooeog',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'YY神曲',
			'apiurl':'http://zyurl.nepian.com/yyshenqu/inc/mac_free.php',
			'flag':'rooo7g',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'b站',
			'apiurl':'http://1zy.wlzhan.com/inc/apibilibili.php',
			'flag':'roo6og',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'2MM',
			'apiurl':'http://zy.vivcms.com/inc/2mm.php',
			'flag':'r9ooog',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'MOVS资源',
			'apiurl':'http://tv.dgua.xyz/inc/api.php',
			'flag':'ro1oog',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'ys帝国资源',
			'apiurl':'http://www.yszydg.com/inc/kuyun.php',
			'flag':'ro2oog',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'强强资源',
			'apiurl':'http://caiji.000o.cc/inc/qq_api.php',
			'flag':'jqqcm_',
			'xt':'1',
			'group':'',
			'ct':''
			},
			
			{
			'status':'ok',
			'name':'ys资源大全',
			'apiurl':'http://www.yszydq.com/inc/api.php',
			'flag':'jppcom_',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'全网ys资源',
			'apiurl':'http://www.daquk.com/inc/api.php',
			'flag':'j9com_',
			'xt':'1',
			'group':'',
			'ct':''
			},
				
					
			{
			'status':'ok',
			'name':'QXK资源',
			'apiurl':'http://zy.19fa.com/inc/api.php',
			'flag':'j900pcom_',
			'xt':'1',
			'group':'',
			'ct':''
			},
			
			{
			'status':'ok',
			'name':'1717云资源',
			'apiurl':'http://zy.1717yun.com/inc/api.php',
			'flag':'jpcom_',
			'xt':'1',
			'group':'',
			'ct':''
			},
			
			{
			'status':'ok',
			'name':'cz资源，无需解析',
			'apiurl':'http://www.czhiyun.com/inc/api.asp',
			'flag':'roqog',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'资源片混合资源',
			'apiurl':'http://www.ziyuanpian.com/inc/api.php',
			'flag':'rzg',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'jiexi混合资源',
			'apiurl':'http://cj.jiexi.cx/inc/api.php',
			'flag':'rng',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'zd混合资源',
			'apiurl':'http://www.zuidazy.com/inc/api.php',
			'flag':'riig',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'速度牛混合资源',
			'apiurl':'http://zy.wlzhan.com/inc/api.php',
			'flag':'rioog',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'石头资源)',
			'apiurl':'http://cj.071811.cc/inc/api.php',
			'flag':'fe77ycom_',
			'xt':'1',
			'group':'2',
			'ct':''
			},
			{
			'status':'ok',
			'name':'OBest整站资源',
			'apiurl':'http://zy.obest.net/inc/api.php',
			'flag':'ryoog',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'Kuyun',
			'apiurl':'http://www.ziyuanpian.com/inc/kuyun.php',
			'flag':'f47om_',
			'xt':'1',
			'group':'1',
			'ct':''
			},
			{
			'status':'ok',
			'name':'131资源',
			'apiurl':'http://www.qwysvip.com/inc/api.php',
			'flag':'fyucom_',
			'xt':'1',
			'group':'2',
			'ct':''
			},
			{
			'status':'ok',
			'name':'百域阁资源',
			'apiurl':'http://baiyug.cn/inc/api.php',
			'flag':'rccog',
			'xt':'1',
			'group':'',
			'ct':''
			},
			
			{
			'status':'ok',
			'name':'jsyun资源，无需解析',
			'apiurl':'http://www.caijizy.com/inc/api.php',
			'flag':'r65og',
			'xt':'1',
			'group':'',
			'ct':''
			},
			{
			'status':'ok',
			'name':'法海云(27盘)',
			'apiurl':'http://cj.tv6.com/mox/inc/27pan.php',
			'flag':'fe23om_',
			'xt':'1',
			'group':'2',
			'ct':''
			}
		]
	}
};

var html='',html2='',url='',url8x='',url7x='',ver='7x',url1='',url2='',url3='',url4='',urlone='',name1='';
url8x='index.php?m=collect-{ac}-ac2-{ac2}-hour-{hour}-xt-{xt}-ct-{ct}-group-{group}-flag-{flag}-apiurl-{apiurl}';
url7x='admin_maccj.php?action={ac}&xt={xt}&ct={ct}&rday={hour}&cjflag={flag}&cjurl={apiurl}';
if(top.location.href.indexOf('maccj')>-1){ ver='7x';url=url7x; } else{ ver='8x';url=url8x; }

$.each(list, function(k1, v1){
	html +="<table width='98%' class='table'><tbody>";
	if(k1=='news'){
		html += "<tr class='table_title red'><td colspan='7' class='td'><span style='float:left'>&nbsp;离线资源采集平台&nbsp;</span><span style='float:right'>本资源采集插件由爱看撒免费提供[官方群:593567857],如果有什么疑问请加群交流，如果你有好的资源采集清分享给我&nbsp;</span></td></tr>";
	}
	html += "<tr class='table_title'><td colspan='7' class='td'><span style='float:left'>&nbsp;"+v1.des+"</span><span style='float:right'>&nbsp;</span></td></tr>";
	
	$.each(v1.rows, function(k2, v2){
		urlone = url.replace('{xt}',v2.xt).replace('{ct}',v2.ct).replace('{group}',v2.group).replace('{flag}',v2.flag).replace('{apiurl}',v2.apiurl);
		name1 = v2.name;
		if(ver=='8x'){
			url1= urlone.replace('{ac}','list').replace('{ac2}','').replace('{hour}','');
			url2= urlone.replace('{ac}','cj').replace('{ac2}','day').replace('{hour}','24');
			url3= urlone.replace('{ac}','cj').replace('{ac2}','day').replace('{hour}','98');
			url4= urlone.replace('{ac}','cj').replace('{ac2}','all').replace('{hour}','');
		}
		else{
			url1= urlone.replace('{ac}','list').replace('{ac2}','').replace('{hour}','');
			url2= urlone.replace('{ac}','cjday').replace('{ac2}','').replace('{hour}','24');
			url3= urlone.replace('{ac}','cjday').replace('{ac2}','').replace('{hour}','98');
			url4= urlone.replace('{ac}','cjall').replace('{ac2}','').replace('{hour}','');
		}
		
		html += "<tr><td width='20'>0"+(k2+1)+"、</td>"+'<td width="30" align=center><em class="u'+v2.status+'"><em></td>'+"<td><a href='"+url1+"'> "+name1+" </a></td>"+"<td width='60'><a href='"+url2+"'>采集当天</a></td>"+"<td width='60'><a href='"+url3+"'>采集本周</a></td>"+"<td width='60'><a href='"+url4+"'>采集所有</a></td></tr>";
		
		html2 += '<option value="'+url2+'">'+name1+'</option>';
	});
	html+='</tbody></table>';
});
html2 = '<select id="ds_url" name="ds_url" multiple style=" width:400px;height:300px">' + html2 + '</select>';

document.write('<style type="text/css">.table {margin-bottom:5px;font-size:12px;text-align:left;border-collapse: collapse;border: 1px solid #C6DCF2; }.table td {padding-left:10px;padding-right:10px;border: 1px solid #C6DCF2; }.table .td {height:25px;padding-left:0px;} .table tr {height:25px;line-height:25px;}.table tr .left{width:180px;text-align:right;padding-right:10px;color:#666;} .table_title {height:25px;line-height:25px;background: #F3F7FB;font-weight:bold;color:#0099cc;}.uok{width:30px;height:15px;color:white;background-color:green;display:-moz-inline-box;display:inline-block;}.uerr{width:30px;height:15px;color:white;background-color:red;display:-moz-inline-box;display:inline-block;}.red{color:red;}</style>');

h=20;
if(h>=19 || h<=1){
	if( typeof typeids != 'undefined' ){
		document.write(html2);
	}
	else{
		document.write(html);
	}
	
}
else{
	document.write('<font style="color:red;font-size:26px">关闭中，请从视频网站获取正版数据外链调用地址。<br></font><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>');
}
